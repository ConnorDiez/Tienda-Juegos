<?php
//session_start();

if(isset($_SESSION["error"])){
    echo $_SESSION["error"];
    unset($_SESSION["error"]);
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link href="favicon.ico" rel="icon" type="image/ico" />
    <link rel="stylesheet" href="public/css/estilos.css">
    
</head>


<body>
    <section class="form-login">
       <form method="post" action="login.php">
             <h5>Login</h5>
            <input class="controls" type="text" name="usuario" value="" placeholder="Usuario">
            <input class="controls" type="password" name="contrasena" value="" placeholder="Contraseña">
            <input class="buttons" type="submit" name="" value="Ingresar">
            <p><a href="#">¿Olvidaste la contraseña?</a></p>
            <p><a href="register.php">Registrar</a></p>
        </form>
    </section>
    
</body>
</html>