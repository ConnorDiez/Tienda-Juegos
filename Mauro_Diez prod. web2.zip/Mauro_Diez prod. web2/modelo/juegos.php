<?php

    include("../conn.php");


    class Juegos {


        public static function listJuego(){
            global $mysqli;
/*
            $sql = "SELECT id,nombre,precio,genero,imagen
                    FROM juegos";


            if (!$resultado = $mysqli->query($sql)) {
                echo "Lo sentimos, este sitio web está experimentando problemas.";
                echo "Error: La ejecución de la consulta falló debido a: \n";
                echo "Query: " . $sql . "\n";
                echo "Errno: " . $mysqli->errno . "\n";
                echo "Error: " . $mysqli->error . "\n";
            }

         */

            $resultado = $mysqli->query("SELECT * FROM juegos");
			$rows = array();
         //   print_r($resultado);
			while($row = $resultado->fetch_assoc()) {


		    	$nombre = $row["nombre"];
				$precio = $row["precio"];
				$genero = $row["genero"];
                $imagen = $row["imagen"];

			//	$rows[] = new Juego($nombre,$precio,$genero,$imagen);

               // echo "$nombre, $precio, $genero, $imagen";
               $array = array('nombre' => $nombre, 'precio' =>$precio , 'genero' =>$genero, 'imagen' => $imagen);
              //  print_r($array);
                array_push($rows, $array);

               // echo '</br>';
                
			}
            //echo json_encode($rows);
			return $rows;
        }
    

        public static function crearJuego($nombre, $precio, $genero, $imagen){


            global $mysqli;
			$query = $mysqli->query("INSERT INTO `juegos` (`id`, `nombre`, `precio`, `genero`, `imagen`) VALUES (NULL, '$nombre', '$precio', '$genero', '$imagen')");
			if(!$query){
				die($mysqli->error);
			}

        }

    }

    class Juego{

		public $nombre;
		public $precio;
		public $genero;
        public $imagen;

		public function __construct($nombre,$precio,$genero,$imagen){
			$this->nombre = $nombre;
			$this->precio = $precio;
			$this->genero = $genero;
            $this->imagen = $imagen;
		}

	}

?>