<?php

    include("conn.php");


    class UsuariosDAO {

        //public static $FILE = "modelo/usuarios.json";

        public static function usuarioOcupado($usuario){

            $content = file_get_contents(UsuariosDAO::$FILE);
    
            $arr_usuarios = json_decode($content, true);
            
            $return = false;
            foreach ($arr_usuarios as $cred){
    
                if ($cred["user"] == $usuario){
                    $return = true;
                    break;
                }
    
            }
    
            return $return;
    
        }

        public static function existeUsuario($usuario, $pwd){
            global $mysqli;

            $sql = "SELECT U.id, U.nombre, U.email, U.pass 
                    FROM usuarios U
                    WHERE U.user = '$usuario' AND U.pass = '$pwd'";


            if (!$resultado = $mysqli->query($sql)) {
                echo "Lo sentimos, este sitio web está experimentando problemas.";
                echo "Error: La ejecución de la consulta falló debido a: \n";
                echo "Query: " . $sql . "\n";
                echo "Errno: " . $mysqli->errno . "\n";
                echo "Error: " . $mysqli->error . "\n";
            }

            if ($resultado->num_rows === 0) {
                echo "Lo sentimos. No se pudo encontrar una coincidencia para el ID $usuario. Inténtelo de nuevo.";
                return false;
            } else {
                echo 'SI SE ENCONTRO';
                return true;
            }

            exit;
        }
    

        public static function crearUsuario($usuario, $pwd, $email, $edad){
        //      $edad=25;
        //    $email=$usuario;


            global $mysqli;
			$query = $mysqli->query("INSERT INTO usuarios(nombre, user, edad,email,pass) VALUES ('$usuario','$usuario',$edad,'$email','$pwd')");
			if(!$query){
				die($mysqli->error);
			}

        }

    }



?>