<?php

    session_start();

    echo "Bienvenido";
    print_r($_SESSION);


    echo "<a href= 'logout.php'> Salir</a> ";

?>