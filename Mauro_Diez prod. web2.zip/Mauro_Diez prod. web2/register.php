<!--  
    1. Crear un formulario en html para pedir los datos
    2. Enviar al servidor.
    3. Recibir por metodo $_POST['user']
    4. Llamar a la funcion Crear usuario.
    5. Redirigir al Index.


-->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registrarse</title>
    <link rel="stylesheet" href="css/estilos.css">
    
</head>


<body>
    <section class="form-login">
       <form method="post" action="crearUsuario.php">
            <h5>Registrarse</h5>
            <input class="controls" type="text" name="usuario" value="" placeholder="Usuario">
            <input class="controls" type="password" name="contrasena1" value="" placeholder="Contraseña">
            <input class="controls" type="password" name="contrasena2" value="" placeholder="Repita la Contraseña">
            <input class="controls" type="text" name="email" value="" placeholder="Email">
            <input class="controls" type="text" name="edad" value="" placeholder="Edad">
            <input class="buttons" type="submit" name="" value="Registrar">
        </form>
    </section>
    
</body>
</html>