<?php


    require_once("modelo/usuario.php");

    // Recibe los datos del usuario para crear
    if( isset($_POST['usuario']) && isset($_POST['contrasena1']) && isset($_POST['contrasena2'])
     && isset($_POST['email']) && isset($_POST['edad'])  ){
        // Asignar a varibles los datos
        $usuario = $_POST['usuario'];
        $contrasena1 = $_POST['contrasena1'];
        $contrasena2 = $_POST['contrasena2'];
        $email = $_POST['email'];
        $edad = $_POST['edad'];

        // Tarea Valida que contrasena1 sea igual que contrasena2... 
        if ( $contrasena1 == $contrasena2 ){

            $objUsuario=new UsuariosDAO();
            $objUsuario->crearUsuario($usuario, $contrasena1, $email, $edad);
            // Guardar los datos
           // crearUsuario($usuario, $contrasena1);
            echo '<h4>Usuario Registrado</h4>';
            echo "<a href= 'index.php'> ir a inicio</a> ";
            // Mostrar mensaje Usuarios y redirigir al Index.php
        } else {
            // Informar que las contraseñas no conicide y redirigir al register.php
             echo 'las contraseñas no coiciden';
             header("Location: index.php");
        }



            
    }else{
        echo 'Error al recibir los datos'; 
    }

?>