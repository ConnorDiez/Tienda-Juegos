<?php

session_start();
$_SESSION ['error'] = 'no hubo error';

//require("./daos/usuarios.php");
require_once("modelo/usuario.php");

if(isset($_POST['usuario']) && isset($_POST['contrasena'])){

   // if($_POST['usuario']=='admin' && $_POST['contrasena']=='1234'){
$_usuario = $_POST['usuario'];
$_pwd = $_POST['contrasena'];

$objUsuario=new UsuariosDAO();
//$objUsuario->existeUsuario($_usuario, $_pwd);

//echo $_usuario;
//echo $_pwd;

    if( $objUsuario->existeUsuario($_usuario, $_pwd)){


        $_SESSION['usuario'] = $_POST['usuario'];
        header("Location: view/home.php");
        
    }else{
    
        $_SESSION['error'] = 'hubo un problema en la sesion';
        header("Location: index.php");
     }
        
}else{
        header("Location: index.php");
    

}


?>